package com.atguigu.contexttest;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends Activity {
    public MainActivity() {
        Log.e("TAG", "MainActivity MainActivity()");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //调用Context的方法：
        Context applicationContext = this.getApplicationContext();
        //调用activity的方法：
        MyApplication application = (MyApplication) this.getApplication();

        Log.e("TAG", "applicationContext == application :" + (application == applicationContext));
        Log.e("TAG", "object:" + application.getClass().toString());

        application.setData("友谊的小船说翻就翻");
        

    }
    
    public void startService(View v) {
        startService(new Intent(this,MyService.class));
//        new AlertDialog.Builder(this.getApplication())
//                .setTitle("1111")
//                .setPositiveButton("确定", null)
//                .setNegativeButton("取消", null)
//                .show();
        Toast.makeText(getApplicationContext(), "application", Toast.LENGTH_SHORT).show();

    }
}
