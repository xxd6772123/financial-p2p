package com.atguigu.p2pinvest0714.adapter;

import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.atguigu.p2pinvest0714.R;
import com.atguigu.p2pinvest0714.bean.Product;
import com.atguigu.p2pinvest0714.utils.UIUtils;

import java.util.List;

/**
 * Created by shkstart on 2016/11/15 0015.
 */
public class ProductAdapter2 extends MyBaseAdapter2<Product> {
    public ProductAdapter2(List<Product> list) {
        super(list);
    }

    @Override
    protected void setData(View convertView, Product product) {
        ((TextView)convertView.findViewById(R.id.p_name)).setText(product.name);
        //一共需要提供7项的赋值

        Log.e("TAG", "setData()");
    }

    @Override
    protected View initView() {
        return UIUtils.getView(R.layout.item_product_list);
    }
}
