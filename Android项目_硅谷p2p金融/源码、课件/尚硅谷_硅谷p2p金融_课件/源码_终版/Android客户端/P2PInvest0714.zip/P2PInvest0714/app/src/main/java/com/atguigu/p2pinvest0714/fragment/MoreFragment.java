package com.atguigu.p2pinvest0714.fragment;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.atguigu.p2pinvest0714.R;
import com.atguigu.p2pinvest0714.activity.GestureEditActivity;
import com.atguigu.p2pinvest0714.activity.GuiGuInvestActivity;
import com.atguigu.p2pinvest0714.activity.UserRegisterActivity;
import com.atguigu.p2pinvest0714.common.AppNetConfig;
import com.atguigu.p2pinvest0714.common.BaseActivity;
import com.atguigu.p2pinvest0714.common.BaseFragment;
import com.atguigu.p2pinvest0714.utils.UIUtils;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import java.io.UnsupportedEncodingException;

import butterknife.Bind;
import butterknife.OnClick;
import cn.sharesdk.onekeyshare.OnekeyShare;

/**
 * Created by shkstart on 2016/11/11 0011.
 * 1.如何创建Fragment,重写onCreateView()
 * 2.如何在activity中加载Fragment:①静态加载 ②动态加载
 */
public class MoreFragment extends BaseFragment {


    @Bind(R.id.iv_top_back)
    ImageView ivTopBack;
    @Bind(R.id.tv_top_title)
    TextView tvTopTitle;
    @Bind(R.id.iv_top_setting)
    ImageView ivTopSetting;
    @Bind(R.id.ll_more_regist)
    LinearLayout llMoreRegist;
    @Bind(R.id.toggle_more_secret)
    ToggleButton toggleMoreSecret;
    @Bind(R.id.ll_more_reset)
    LinearLayout llMoreReset;
    @Bind(R.id.tv_more_number)
    TextView tvMoreNumber;
    @Bind(R.id.ll_more_contact)
    LinearLayout llMoreContact;
    @Bind(R.id.ll_more_sms)
    LinearLayout llMoreSms;
    @Bind(R.id.ll_more_share)
    LinearLayout llMoreShare;
    @Bind(R.id.ll_more_about)
    LinearLayout llMoreAbout;
    private SharedPreferences sp;

    @Override
    protected RequestParams getParams() {
        return null;
    }

    @Override
    protected String getUrl() {
        return null;
    }

    @Override
    protected void initData(String content) {

        //获取设置手势密码的ToggleButton的状态
        getGestureStatus();
        //设置手势密码的ToggleButton状态改变的监听
        setGestureListener();

        //设置重置手势密码的操作
        resetGestureListener();

        //联系客服
        contactSupportStaff();

        //反馈信息
        fanKui();

        //分享给好友
        share();

        //关于硅谷理财
        aboutGuiguInvest();
    }


    private void share() {
        llMoreShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showShare();
            }
        });

    }
    //分享
    private void showShare(){
        OnekeyShare oks = new OnekeyShare();
        //关闭sso授权
        oks.disableSSOWhenAuthorize();
        // title标题，印象笔记、邮箱、信息、微信、人人网、QQ和QQ空间使用
        oks.setTitle(getResources().getString(R.string.app_name));
        // titleUrl是标题的网络链接，仅在Linked-in,QQ和QQ空间使用
        oks.setTitleUrl("http://www.atguigu.com");
        // text是分享文本，所有平台都需要这个字段
        oks.setText("世界上最遥远的距离，是我在if里你在else里，似乎一直相伴又永远分离；\n" +
                "     世界上最痴心的等待，是我当case你是switch，或许永远都选不上自己；\n" +
                "     世界上最真情的相依，是你在try我在catch。无论你发神马脾气，我都默默承受，静静处理。到那时，再来期待我们的finally。");
        //分享网络图片，新浪微博分享网络图片需要通过审核后申请高级写入接口，否则请注释掉测试新浪微博
        oks.setImageUrl("http://f1.sharesdk.cn/imgs/2014/02/26/owWpLZo_638x960.jpg");
        // imagePath是图片的本地路径，Linked-In以外的平台都支持此参数
        //oks.setImagePath("/sdcard/test.jpg");//确保SDcard下面存在此张图片

        // url仅在微信（包括好友和朋友圈）中使用
        oks.setUrl("http://www.atguigu.com");
        // comment是我对这条分享的评论，仅在人人网和QQ空间使用
        oks.setComment("word妈呀，精辟的不要不要的！");
        // site是分享此内容的网站名称，仅在QQ空间使用
        oks.setSite(getResources().getString(R.string.app_name));
        // siteUrl是分享此内容的网站地址，仅在QQ空间使用
        oks.setSiteUrl("http://www.atguigu.com");

        // 启动分享GUI
        oks.show(this.getActivity());
    }

    //关于硅谷理财
    private void aboutGuiguInvest() {
        llMoreAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((BaseActivity) MoreFragment.this.getActivity()).goToActivity(GuiGuInvestActivity.class, null);
            }
        });
    }

    private String department = "用户未选择";

    //反馈信息
    private void fanKui() {

        llMoreSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final View view = View.inflate(MoreFragment.this.getActivity(), R.layout.view_fankui, null);
                final RadioGroup rg_fankui = (RadioGroup) view.findViewById(R.id.rg_fankui);
                //获取选中的部门
                rg_fankui.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup group, int checkedId) {
                        //获取选中的部门信息
                        RadioButton rb_fankui = (RadioButton) rg_fankui.findViewById(checkedId);
                        department = rb_fankui.getText().toString();
                    }
                });

                new AlertDialog.Builder(MoreFragment.this.getActivity())
                        .setView(view)
                        .setPositiveButton("发送", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                EditText et_fankui_content = (EditText) view.findViewById(R.id.et_fankui_content);
                                String fanKuiContent = et_fankui_content.getText().toString();
                                //将反馈信息发送给服务器
                                AsyncHttpClient client = new AsyncHttpClient();
                                String url = AppNetConfig.FEEDBACK;
                                RequestParams params = new RequestParams();

                                try {
                                    //为了避免出现乱码，必须如下处理
                                    department = new String(department.getBytes(), "utf-8");
                                    params.put("department", department);
                                    fanKuiContent = new String(fanKuiContent.getBytes(), "utf-8");
                                    params.put("content", fanKuiContent);
                                    client.post(url, params, new AsyncHttpResponseHandler() {
                                        @Override
                                        public void onSuccess(String content) {
                                            Toast.makeText(MoreFragment.this.getActivity(), "发送反馈信息成功", Toast.LENGTH_SHORT).show();
                                        }

                                        @Override
                                        public void onFailure(Throwable error, String content) {
                                            Toast.makeText(MoreFragment.this.getActivity(), "发送反馈信息失败", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                } catch (UnsupportedEncodingException e) {
                                    e.printStackTrace();
                                }
                            }
                        })
                        .setNegativeButton("取消", null)
                        .show();
            }
        });
    }
    //联系客服
    private void contactSupportStaff() {
        llMoreContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MoreFragment.this.getActivity())
                        .setTitle("联系客服")
                        .setMessage("是否联系客服010-56253825")
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intent = new Intent(Intent.ACTION_CALL);

                                Uri uri = Uri.parse("tel:010-56253825");
                                intent.setData(uri);
                                try {
                                    MoreFragment.this.getActivity().startActivity(intent);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        })
                        .setNegativeButton("取消", null)
                        .show();
            }
        });
    }

    //设置重置手势密码的操作
    private void resetGestureListener() {
        llMoreReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //获取当前ToggleButton的状态
                boolean checked = toggleMoreSecret.isChecked();
                if (!checked) {
                    Toast.makeText(UIUtils.getContext(), "您尚未开启手势密码", Toast.LENGTH_SHORT).show();
                    return;
                }

                new AlertDialog.Builder(MoreFragment.this.getActivity())
                        .setTitle("重置手势密码")
                        .setMessage("是否重置手势密码")
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ((BaseActivity) MoreFragment.this.getActivity()).goToActivity(GestureEditActivity.class, null);
                            }
                        })
                        .setNegativeButton("取消", null)
                        .show();
            }
        });
    }

    //设置手势密码的ToggleButton状态改变的监听
    private void setGestureListener() {
        toggleMoreSecret.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    //判断本地是否设置过手势密码
                    String inputCode = sp.getString("inputCode", "");
                    if (TextUtils.isEmpty(inputCode)) {
                        new AlertDialog.Builder(MoreFragment.this.getActivity())
                                .setTitle("设置手势密码")
                                .setMessage("是否现在设置手势密码")
                                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Toast.makeText(UIUtils.getContext(), "现在设置手势密码", Toast.LENGTH_SHORT).show();
//                                        toggleMoreSecret.setChecked(true);
                                        sp.edit().putBoolean("isOpen", true).commit();
                                        ((BaseActivity) (MoreFragment.this.getActivity())).goToActivity(GestureEditActivity.class, null);
                                    }
                                })
                                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Toast.makeText(UIUtils.getContext(), "取消了手势密码设置", Toast.LENGTH_SHORT).show();
                                        toggleMoreSecret.setChecked(false);
                                        sp.edit().putBoolean("isOpen", false).commit();
                                    }
                                })
                                .show();

                    } else {//之前设置过
                        Toast.makeText(UIUtils.getContext(), "开启手势解锁", Toast.LENGTH_SHORT).show();
//                        toggleMoreSecret.setChecked(true);
                        sp.edit().putBoolean("isOpen", true).commit();
                    }


                } else {
                    Toast.makeText(UIUtils.getContext(), "关闭手势解锁", Toast.LENGTH_SHORT).show();
                    //  toggleMoreSecret.setChecked(false);
                    sp.edit().putBoolean("isOpen", false).commit();

                }
            }
        });
    }

    //获取设置手势密码的ToggleButton的状态
    private void getGestureStatus() {
        sp = this.getActivity().getSharedPreferences("secret_protect", Context.MODE_PRIVATE);
        //读取当前的toggleButton的状态并显示
        boolean isOpen = sp.getBoolean("isOpen", false);
        toggleMoreSecret.setChecked(isOpen);
    }

    public void initTitle() {
        ivTopBack.setVisibility(View.INVISIBLE);
        ivTopSetting.setVisibility(View.INVISIBLE);
        tvTopTitle.setText("更多");
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_more;
    }

    @OnClick(R.id.ll_more_regist)
    public void regist(View view) {
        ((BaseActivity) getActivity()).goToActivity(UserRegisterActivity.class, null);
    }
}
