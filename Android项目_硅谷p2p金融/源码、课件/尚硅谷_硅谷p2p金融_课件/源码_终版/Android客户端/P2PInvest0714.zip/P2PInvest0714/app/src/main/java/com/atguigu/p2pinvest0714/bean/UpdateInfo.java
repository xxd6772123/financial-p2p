package com.atguigu.p2pinvest0714.bean;

/**
 * Created by shkstart on 2016/11/19 0019.
 */
public class UpdateInfo {

    public String version;//版本号
    public String apkUrl;//应用文件访问路径
    public String desc;//版本更新信息

}
