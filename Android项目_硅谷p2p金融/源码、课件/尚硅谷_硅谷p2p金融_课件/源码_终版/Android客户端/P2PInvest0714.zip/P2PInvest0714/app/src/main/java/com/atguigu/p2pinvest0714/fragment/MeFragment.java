package com.atguigu.p2pinvest0714.fragment;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.atguigu.p2pinvest0714.R;
import com.atguigu.p2pinvest0714.activity.BarChartActivity;
import com.atguigu.p2pinvest0714.activity.ChongZhiActivity;
import com.atguigu.p2pinvest0714.activity.GestureVerifyActivity;
import com.atguigu.p2pinvest0714.activity.LineChartActivity;
import com.atguigu.p2pinvest0714.activity.LoginActivity;
import com.atguigu.p2pinvest0714.activity.PieChartActivity;
import com.atguigu.p2pinvest0714.activity.TiXianActivity;
import com.atguigu.p2pinvest0714.activity.UserInfoActivity;
import com.atguigu.p2pinvest0714.bean.User;
import com.atguigu.p2pinvest0714.common.BaseActivity;
import com.atguigu.p2pinvest0714.common.BaseFragment;
import com.atguigu.p2pinvest0714.utils.BitmapUtils;
import com.atguigu.p2pinvest0714.utils.UIUtils;
import com.loopj.android.http.RequestParams;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import java.io.File;

import butterknife.Bind;
import butterknife.OnClick;

/**
 * Created by shkstart on 2016/11/11 0011.
 */
public class MeFragment extends BaseFragment {


    @Bind(R.id.iv_top_back)
    ImageView ivTopBack;
    @Bind(R.id.tv_top_title)
    TextView tvTopTitle;
    @Bind(R.id.iv_top_setting)
    ImageView ivTopSetting;
    @Bind(R.id.imageView1)
    ImageView imageView1;
    @Bind(R.id.icon_time)
    RelativeLayout iconTime;
    @Bind(R.id.textView11)
    TextView textView11;
    @Bind(R.id.relativeLayout1)
    RelativeLayout relativeLayout1;
    @Bind(R.id.recharge)
    ImageView recharge;
    @Bind(R.id.withdraw)
    ImageView withdraw;
    @Bind(R.id.ll_touzi)
    TextView llTouzi;
    @Bind(R.id.ll_touzi_zhiguan)
    TextView llTouziZhiguan;
    @Bind(R.id.ll_zichang)
    TextView llZichang;
    private SharedPreferences sp;

    @Override
    protected RequestParams getParams() {
        return null;
    }

    @Override
    protected String getUrl() {
        return null;
    }

    @Override
    protected void initData(String content) {
        sp = this.getActivity().getSharedPreferences("secret_protect", Context.MODE_PRIVATE);
        //判断是否需要进行登录的提示
        isLogin();
    }

    @Override
    protected void initTitle() {
        ivTopBack.setVisibility(View.INVISIBLE);
        ivTopSetting.setVisibility(View.VISIBLE);
        tvTopTitle.setText("我的资产");
    }

    //点击“设置”的图标，启动新的用户信息的Activity
    @OnClick(R.id.iv_top_setting)
    public void setting(View view) {
        ((BaseActivity) this.getActivity()).goToActivity(UserInfoActivity.class, null);
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_me;
    }

    private void isLogin() {
        //在本应用对应的sp存储的位置，是否已经保存了用户的登录信息。
        SharedPreferences sp = this.getActivity().getSharedPreferences("user_info", Context.MODE_PRIVATE);
        String userName = sp.getString("name", "");
        if (TextUtils.isEmpty(userName)) {//如果没有保存：提示AlertDialog
            login();
        } else {//如果保存了：读取sp中的用户信息，并显示在页面上
            doUser();
        }

    }

    /**
     * 当当前的Fragment显示时，考虑是否需要从本地读取用户头像
     */
    @Override
    public void onResume() {
        super.onResume();

        String filePath = this.getActivity().getCacheDir() + "/tx.png";
        File file = new File(filePath);
        if (file.exists()) {//如果存在
            //存储--->内存
            Bitmap bitmap = BitmapFactory.decodeFile(filePath);
            imageView1.setImageBitmap(bitmap);
        }
    }

    //得到了本地的登录信息，加载显示
    private void doUser() {
        //读取数据，得到内存中的User对象
        User user = ((BaseActivity) this.getActivity()).readUser();
        //一方面，显示用户名
        textView11.setText(user.name);

        String filePath = this.getActivity().getCacheDir() + "/tx.png";
        File file = new File(filePath);
        if (file.exists()) {
            return;
        }


        //另一方面，加载显示用户头像
        Picasso.with(getActivity()).load(user.imageUrl).transform(new Transformation() {
            @Override
            public Bitmap transform(Bitmap source) {//source:矩形的Bitmap对象
                //1.压缩处理
                Bitmap zoomBitmp = BitmapUtils.zoom(source, UIUtils.dp2px(62), UIUtils.dp2px(62));
                //2.圆形处理
                Bitmap bitmap = BitmapUtils.circleBitmap(zoomBitmp);
                //回收source
                source.recycle();
                return bitmap;//返回圆形的Bitmap对象
            }

            @Override
            public String key() {
                return "";//只要返回值不为空即可
            }
        }).into(imageView1);


        //如果在本地fanx发现用户设置过手势密码，则在此时验证
        boolean isOpen = sp.getBoolean("isOpen", false);
        if (isOpen) {
            ((BaseActivity) this.getActivity()).goToActivity(GestureVerifyActivity.class, null);
        }
    }

    //未发现登录信息，提示用户登录的Dialog
    private void login() {
        new AlertDialog.Builder(getActivity())
                .setTitle("提示")
                .setMessage("请先登录哦")
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
//                            Toast.makeText(MeFragment.this.getActivity(), "请先登录", Toast.LENGTH_SHORT).show();
                        //启动activity
                        ((BaseActivity) MeFragment.this.getActivity()).goToActivity(LoginActivity.class, null);
                    }
                })
                .setCancelable(false)
                .show();
    }

    @OnClick(R.id.recharge)
    public void setRecharge(View view) {
        ((BaseActivity) this.getActivity()).goToActivity(ChongZhiActivity.class, null);
    }

    @OnClick(R.id.withdraw)
    public void withdraw(View view) {
        ((BaseActivity) this.getActivity()).goToActivity(TiXianActivity.class, null);
    }

    @OnClick(R.id.ll_touzi)
    public void startLineChart(View view) {
        ((BaseActivity) this.getActivity()).goToActivity(LineChartActivity.class, null);
    }

    @OnClick(R.id.ll_touzi_zhiguan)
    public void startBarChart(View view) {
        ((BaseActivity) this.getActivity()).goToActivity(BarChartActivity.class, null);
    }

    @OnClick(R.id.ll_zichang)
    public void startPieChart(View view) {
        ((BaseActivity) this.getActivity()).goToActivity(PieChartActivity.class, null);
    }

}
