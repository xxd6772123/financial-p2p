package com.atguigu.p2pinvest0714.fragment;

import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.atguigu.p2pinvest0714.R;
import com.atguigu.p2pinvest0714.adapter.ProductAdapter3;
import com.atguigu.p2pinvest0714.bean.Product;
import com.atguigu.p2pinvest0714.common.AppNetConfig;
import com.atguigu.p2pinvest0714.common.BaseFragment;
import com.loopj.android.http.RequestParams;

import java.util.List;

import butterknife.Bind;

/**
 * Created by shkstart on 2016/11/15 0015.
 * <p/>
 * 关于ListView的使用：4个元素：①ListView ②集合数据 ③ Adapter ④ item layout
 */
public class ProductListFragment extends BaseFragment {
    @Bind(R.id.lv_product_list)
    ListView lvProductList;
    @Bind(R.id.tv_product_title)
    TextView tvProductTitle;
    private List<Product> products;

    @Override
    protected RequestParams getParams() {
        return null;
    }

    @Override
    protected String getUrl() {
        return AppNetConfig.PRODUCT;
    }

    @Override
    protected void initData(String content) {//content即为响应成功情况下，返回的product.json数据
        //跑马灯实现方式一：
        tvProductTitle.setFocusable(true);
        tvProductTitle.setFocusableInTouchMode(true);
        tvProductTitle.requestFocus();

        //解析json数据
        JSONObject jsonObject = JSON.parseObject(content);
        boolean isSuccess = jsonObject.getBoolean("success");
        if (isSuccess) {
            String data = jsonObject.getString("data");
            //解析得到集合数据
            products = JSON.parseArray(data, Product.class);
        }

//        //创建Adapter的实例
//        ProductAdapter productAdapter = new ProductAdapter(products);
//        //显示列表
//        lvProductList.setAdapter(productAdapter);

        //通用方式一：暴露getView()供子类实现。开发中可以使用
//        ProductAdapter1 productAdapter1 = new ProductAdapter1(products);
//        lvProductList.setAdapter(productAdapter1);

        //通用方式二：并没有使用ViewHolder减少findViewById()执行次数。开发中不可取。
//        ProductAdapter2 productAdapter2 = new ProductAdapter2(products);
//        lvProductList.setAdapter(productAdapter2);
        //通用方式三：既使用了ViewHolder，同时实现了更简洁的抽取
        ProductAdapter3 productAdapter3 = new ProductAdapter3(products);
        lvProductList.setAdapter(productAdapter3);

    }

    @Override
    protected void initTitle() {

    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_product_list;
    }

}
