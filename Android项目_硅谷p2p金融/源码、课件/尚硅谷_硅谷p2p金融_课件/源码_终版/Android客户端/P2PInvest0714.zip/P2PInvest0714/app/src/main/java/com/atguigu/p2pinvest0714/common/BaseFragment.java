package com.atguigu.p2pinvest0714.common;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.atguigu.p2pinvest0714.ui.LoadingPage;
import com.loopj.android.http.RequestParams;

import butterknife.ButterKnife;

/**
 * Created by shkstart on 2016/11/14 0014.
 */
public abstract class BaseFragment extends Fragment {

    public LoadingPage loadingPage;

    //返回一个关联的布局文件生成的视图
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

//        //方式一：使用Appllication的实例作为Context的对象
//        View view = UIUtils.getView(getLayoutId());
//        ButterKnife.bind(this, view);
//
//        //初始化视图组件
//        initTitle();
//
//        //初始化页面数据
//        initData();
//        return view;

        loadingPage = new LoadingPage(getActivity()) {

            @Override
            public int layoutId() {
                return getLayoutId();
            }

            @Override
            protected void onSuccess(ResultState resultState, View view_success) {
                ButterKnife.bind(BaseFragment.this, view_success);//别忘了绑定布局

                initTitle();
                initData(resultState.getContent());

            }

            @Override
            protected RequestParams params() {
                return getParams();
            }

            @Override
            protected String url() {
                return getUrl();
            }
        };

        return loadingPage;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        show();
    }

    protected abstract RequestParams getParams();

    protected abstract String getUrl();

    protected abstract void initData(String content);

    protected abstract void initTitle();

    public abstract int getLayoutId();

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }

    //实现联网操作
    public void show(){

//        UIUtils.getHandler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                loadingPage.show();
//            }
//        },2000);
        loadingPage.show();
    }
}
