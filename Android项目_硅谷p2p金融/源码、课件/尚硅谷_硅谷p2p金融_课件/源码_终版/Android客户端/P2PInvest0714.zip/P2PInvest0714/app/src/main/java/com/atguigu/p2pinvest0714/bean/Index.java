package com.atguigu.p2pinvest0714.bean;

import java.util.List;

/**
 * Created by shkstart on 2016/11/12 0012.
 */
public class Index {

    public Product product;
    public List<Image> images;

}
