package com.atguigu.p2pinvest0714.bean;

/**
 * Created by shkstart on 2016/11/12 0012.
 */
public class Product {

    public String id;
    public String memberNum;
    public String minTouMoney;
    public String money;
    public String name;
    public String progress;
    public String suodingDays;
    public String yearRate;


}
