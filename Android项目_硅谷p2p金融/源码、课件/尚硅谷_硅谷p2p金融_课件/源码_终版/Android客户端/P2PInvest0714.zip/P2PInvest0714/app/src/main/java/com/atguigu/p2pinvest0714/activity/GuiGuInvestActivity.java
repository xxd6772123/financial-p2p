package com.atguigu.p2pinvest0714.activity;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.atguigu.p2pinvest0714.R;
import com.atguigu.p2pinvest0714.common.BaseActivity;

import butterknife.Bind;
import butterknife.OnClick;

public class GuiGuInvestActivity extends BaseActivity {

    @Bind(R.id.iv_top_back)
    ImageView ivTopBack;
    @Bind(R.id.tv_top_title)
    TextView tvTopTitle;
    @Bind(R.id.iv_top_setting)
    ImageView ivTopSetting;

    @Override
    protected void initTitle() {

    }

    @OnClick(R.id.iv_top_back)
    public void back(View view){
        removeCurrentActivity();
    }

    @Override
    protected void initData() {

    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_gui_gu_invest;
    }

}
