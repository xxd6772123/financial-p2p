package com.atguigu.p2pinvest0714.activity;

import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.atguigu.p2pinvest0714.MainActivity;
import com.atguigu.p2pinvest0714.R;
import com.atguigu.p2pinvest0714.bean.User;
import com.atguigu.p2pinvest0714.common.AppNetConfig;
import com.atguigu.p2pinvest0714.common.BaseActivity;
import com.atguigu.p2pinvest0714.utils.MD5Utils;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import butterknife.Bind;
import butterknife.OnClick;

public class LoginActivity extends BaseActivity {

    @Bind(R.id.iv_top_back)
    ImageView ivTopBack;
    @Bind(R.id.tv_top_title)
    TextView tvTopTitle;
    @Bind(R.id.iv_top_setting)
    ImageView ivTopSetting;
    @Bind(R.id.textView1)
    TextView textView1;
    @Bind(R.id.log_ed_mob)
    EditText logEdMob;
    @Bind(R.id.about_com)
    RelativeLayout aboutCom;
    @Bind(R.id.tv_2)
    TextView tv2;
    @Bind(R.id.log_ed_pad)
    EditText logEdPad;
    @Bind(R.id.log_log_btn)
    Button logLogBtn;

    @Override
    protected void initTitle() {
        ivTopBack.setVisibility(View.VISIBLE);
        tvTopTitle.setText("用户登录");
        ivTopSetting.setVisibility(View.INVISIBLE);
    }

    @Override
    protected void initData() {

    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_login;
    }

    @OnClick(R.id.iv_top_back)
    public void back(View view){
//        this.removeCurrentActivity();
        this.removeAll();
        goToActivity(MainActivity.class,null);
    }

    @OnClick(R.id.log_log_btn)
    public void login(View view){
        //1.获取手机号和加密以后的密码
        String number = logEdMob.getText().toString().trim();
        String password = logEdPad.getText().toString().trim();
        //判断输入的信息是否存在空
        if(!TextUtils.isEmpty(number) && !TextUtils.isEmpty(password)){
            //2.联网将用户数据发送给服务器，其中手机号和密码作为请求参数
            String url = AppNetConfig.LOGIN;
            RequestParams params = new RequestParams();
            params.put("phone",number);
            params.put("password", MD5Utils.MD5(password));
            client.post(url,params,new AsyncHttpResponseHandler(){
                //3.得到响应数据：成功
                @Override
                public void onSuccess(String content) {
                    Log.e("TAG", content);
                    //3.1解析json数据
                    JSONObject jsonObject = JSON.parseObject(content);
                    boolean isSuccess = jsonObject.getBoolean("success");
                    if(!isSuccess){
                        Toast.makeText(LoginActivity.this, "用户名不存在或密码不正确", Toast.LENGTH_SHORT).show();

                    }else{
                        String data = jsonObject.getString("data");
                        User user = JSON.parseObject(data, User.class);
                        //3.2保存得到的用户信息（使用sp存储）
                        saveUser(user);
                        //3.3重新加载页面，显示用户的信息在MeFragment中
                        LoginActivity.this.removeAll();
                        LoginActivity.this.goToActivity(MainActivity.class,null);
                    }

                }
                //4.连接失败
                @Override
                public void onFailure(Throwable error, String content) {
                    Log.e("TAG", "fail");
                    Toast.makeText(LoginActivity.this, "联网失败", Toast.LENGTH_SHORT).show();
                }
            });
        }else{
            Toast.makeText(LoginActivity.this, "用户名或密码不能为空", Toast.LENGTH_SHORT).show();
        }
    }
}
