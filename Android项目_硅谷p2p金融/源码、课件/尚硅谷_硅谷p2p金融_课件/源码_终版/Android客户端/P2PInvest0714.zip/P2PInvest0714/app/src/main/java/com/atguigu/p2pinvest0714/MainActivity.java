package com.atguigu.p2pinvest0714;

import android.os.Handler;
import android.os.Message;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.atguigu.p2pinvest0714.common.BaseActivity;
import com.atguigu.p2pinvest0714.fragment.HomeFragment;
import com.atguigu.p2pinvest0714.fragment.InvestFragment;
import com.atguigu.p2pinvest0714.fragment.MeFragment;
import com.atguigu.p2pinvest0714.fragment.MoreFragment;
import com.atguigu.p2pinvest0714.utils.UIUtils;

import butterknife.Bind;
import butterknife.OnClick;

public class MainActivity extends BaseActivity {

    private static final int MESSAGE_BACK = 1;
    @Bind(R.id.fl_main)
    FrameLayout flMain;
    @Bind(R.id.iv_main_home)
    ImageView ivMainHome;
    @Bind(R.id.tv_main_home)
    TextView tvMainHome;
    @Bind(R.id.ll_main_home)
    LinearLayout llMainHome;
    @Bind(R.id.iv_main_invest)
    ImageView ivMainInvest;
    @Bind(R.id.tv_main_invest)
    TextView tvMainInvest;
    @Bind(R.id.ll_main_invest)
    LinearLayout llMainInvest;
    @Bind(R.id.iv_main_me)
    ImageView ivMainMe;
    @Bind(R.id.tv_main_me)
    TextView tvMainMe;
    @Bind(R.id.ll_main_me)
    LinearLayout llMainMe;
    @Bind(R.id.iv_main_more)
    ImageView ivMainMore;
    @Bind(R.id.tv_main_more)
    TextView tvMainMore;
    @Bind(R.id.ll_main_more)
    LinearLayout llMainMore;

    private HomeFragment homeFragment;
    private InvestFragment investFragment;
    private MeFragment meFragment;
    private MoreFragment moreFragment;
    private FragmentTransaction transaction;
    private FragmentManager fragmentManager;


    @Override
    protected void initTitle() {

    }

    protected void initData() {
        //默认选中“首页”
        setSelect(0);

    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_main;
    }

    @OnClick({R.id.ll_main_home,R.id.ll_main_invest,R.id.ll_main_me,R.id.ll_main_more})
    public void changeTab(View view){
//        Toast.makeText(MainActivity.this, "设置了点击事件", Toast.LENGTH_SHORT).show();
        switch (view.getId()) {
            case R.id.ll_main_home :
                //提供相应的fragment的显示
                setSelect(0);
                break;
            case R.id.ll_main_invest :
                setSelect(1);
                break;
            case R.id.ll_main_me :
                setSelect(2);
                break;
            case R.id.ll_main_more :
                setSelect(3);
                break;
        }


    }
    //提供相应的fragment的显示
    //如何在activity中动态加载fragment
    private void setSelect(int i) {
        Log.e("TAG", "setSelect -- 0");
        fragmentManager = this.getSupportFragmentManager();
        transaction = fragmentManager.beginTransaction();
        //
        hideFragment();
        //重置ImageView和TextView的选中状态
        resetTab();
        if(i == 0){//首页
            if(homeFragment == null){
                homeFragment = new HomeFragment();//创建对象以后，并不会马上执行其生命周期方法，而是在事务执行commit()，才会执行生命周期方法
                transaction.add(R.id.fl_main, homeFragment);

            }
            //显示
            transaction.show(homeFragment);

            //在执行onCreateView()之前，使用了未被此方法赋值的属性：loadingPage.
//            homeFragment.show();

            //设置选中以后的颜色变化
            ivMainHome.setImageResource(R.drawable.bottom02);
//            tvMainHome.setTextColor(R.color.home_back_selected);//不对
            tvMainHome.setTextColor(UIUtils.getColor(R.color.home_back_selected));

        }else if(i == 1){//投资
            if(investFragment == null){
                investFragment = new InvestFragment();//创建对象以后，并不会马上执行其生命周期方法，而是在事务执行commit()，才会执行生命周期方法
                transaction.add(R.id.fl_main, investFragment);
            }
            //显示
            transaction.show(investFragment);
            //设置选中以后的颜色变化
            ivMainInvest.setImageResource(R.drawable.bottom04);
            tvMainInvest.setTextColor(UIUtils.getColor(R.color.home_back_selected));
        }else if(i == 2){//我的资产
            if(meFragment == null){
                meFragment = new MeFragment();//创建对象以后，并不会马上执行其生命周期方法，而是在事务执行commit()，才会执行生命周期方法
                transaction.add(R.id.fl_main, meFragment);
            }
            //显示
            transaction.show(meFragment);
            //设置选中以后的颜色变化
            ivMainMe.setImageResource(R.drawable.bottom06);
            tvMainMe.setTextColor(UIUtils.getColor(R.color.home_back_selected01));
        }else if(i == 3){//更多
            if(moreFragment == null){
                moreFragment = new MoreFragment();//创建对象以后，并不会马上执行其生命周期方法，而是在事务执行commit()，才会执行生命周期方法
                transaction.add(R.id.fl_main, moreFragment);
            }
            //显示
            transaction.show(moreFragment);
            //设置选中以后的颜色变化
            ivMainMore.setImageResource(R.drawable.bottom08);
            tvMainMore.setTextColor(UIUtils.getColor(R.color.home_back_selected));
        }

        //提交
        transaction.commit();

    }
    //重置ImageView和TextView的选中状态
    private void resetTab() {
        ivMainHome.setImageResource(R.drawable.bottom01);
        ivMainInvest.setImageResource(R.drawable.bottom03);
        ivMainMe.setImageResource(R.drawable.bottom05);
        ivMainMore.setImageResource(R.drawable.bottom07);

        tvMainHome.setTextColor(UIUtils.getColor(R.color.home_back_unselected));
        tvMainInvest.setTextColor(UIUtils.getColor(R.color.home_back_unselected));
        tvMainMe.setTextColor(UIUtils.getColor(R.color.home_back_unselected));
        tvMainMore.setTextColor(UIUtils.getColor(R.color.home_back_unselected));
    }

    //隐藏所有的Fragment的显示
    private void hideFragment() {
        if(homeFragment != null){
            transaction.hide(homeFragment);
        }

        if(investFragment != null){
            transaction.hide(investFragment);
        }
        if(meFragment != null){
            transaction.hide(meFragment);
        }
        if(moreFragment != null){
            transaction.hide(moreFragment);
        }
    }

    /**
     * 实现连续点击两次"返回键"，退出当前应用
     * @param keyCode
     * @param event
     * @return
     */
    private boolean isFlag = true;
    private Handler handler = new Handler(){
        public void handleMessage(Message msg){
            switch (msg.what) {
                case MESSAGE_BACK :
                    isFlag = true;//在2时，恢复isFlag的变量值
                    break;
            }
        }
    };

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {

        if(keyCode == KeyEvent.KEYCODE_BACK && isFlag){//如果操作的是“返回键”
            isFlag = false;
            Toast.makeText(MainActivity.this, "再点击一次退出应用", Toast.LENGTH_SHORT).show();
            //发送延迟消息
            handler.sendEmptyMessageDelayed(MESSAGE_BACK,2000);
            return true;
        }

        return super.onKeyUp(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //保证在activity退出前，移除所有未被执行的消息，避免出现内存泄漏
        handler.removeCallbacksAndMessages(null);//移除所有的消息
//        handler.removeMessages(MESSAGE_BACK);//移除指定id的所有消息
    }
}
