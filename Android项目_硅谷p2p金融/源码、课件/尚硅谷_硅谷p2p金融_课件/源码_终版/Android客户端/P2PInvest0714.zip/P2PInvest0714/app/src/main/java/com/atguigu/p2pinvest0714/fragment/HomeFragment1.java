package com.atguigu.p2pinvest0714.fragment;

/**
 * Created by shkstart on 2016/11/11 0011.
 * 使用ViewPager加载图片显示，使用CirclePagerIndicator显示小圆圈
 */
//public class HomeFragment1 extends Fragment {
//
//
//    @Bind(R.id.iv_top_back)
//    ImageView ivTopBack;
//    @Bind(R.id.tv_top_title)
//    TextView tvTopTitle;
//    @Bind(R.id.iv_top_setting)
//    ImageView ivTopSetting;
//    @Bind(R.id.vp_home)
//    ViewPager vpHome;
//    @Bind(R.id.cp_home)
//    CirclePageIndicator cpHome;
//    @Bind(R.id.tv_home_rate)
//    TextView tvHomeRate;
//
//    //返回一个关联的布局文件生成的视图
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//
//        //方式一：使用Appllication的实例作为Context的对象
////        View view = UIUtils.getView(R.layout.fragment_home);
//        //方式二：使用Activity的实例作为Context的对象
//        View view = View.inflate(getActivity(),R.layout.fragment_home,null);
//        ButterKnife.bind(this, view);
//
//        //初始化视图组件
//        initTitle();
//
//        //初始化页面数据
//        initData();
//        return view;
//    }
//
//    private Index index;
//
//    private void initData() {
//
//        AsyncHttpClient client = new AsyncHttpClient();
//        Log.e("TAG", "client");
//        client.post(AppNetConfig.INDEX, new AsyncHttpResponseHandler() {
//            //成功的获取响应数据
//            @Override
//            public void onSuccess(String content) {//content:
////                Log.e("TAG", "content = ");
//                //1.使用fastJson解析得到的json数据,并封装数据到java对象中
//                JSONObject jsonObject = JSON.parseObject(content);
//
//                String proInfo = jsonObject.getString("proInfo");
//                Product product = JSON.parseObject(proInfo, Product.class);
//
//                String imageArr = jsonObject.getString("imageArr");
//                List<Image> images = JSON.parseArray(imageArr, Image.class);
//
//                index = new Index();
//                index.product = product;
//                index.images = images;
//
//                //2.设置ViewPager,加载显示图片
//                MyAdapter adapter = new MyAdapter();
//                vpHome.setAdapter(adapter);
//                cpHome.setViewPager(vpHome);
//                //3.根据得到的产品的数据，更新界面中的产品展示
//                String yearRate = index.product.yearRate;
//                tvHomeRate.setText(yearRate + "%");
//
//            }
//
//            //访问服务器失败
//            @Override
//            public void onFailure(Throwable error, String content) {
//                Toast.makeText(getActivity(), "获取服务器数据失败", Toast.LENGTH_SHORT).show();
//            }
//        });
//
//
//    }
//
//    private void initTitle() {
//        ivTopBack.setVisibility(View.INVISIBLE);
//        ivTopSetting.setVisibility(View.INVISIBLE);
//        tvTopTitle.setText("首页");
//    }
//
//    @Override
//    public void onDestroyView() {
//        super.onDestroyView();
//        ButterKnife.unbind(this);
//    }
//
//    //内部提供PagerAdapter子类
//    class MyAdapter extends PagerAdapter{
//
//        @Override
//        public int getCount() {
//            return index.images == null ? 0 : index.images.size();
//        }
//
//        //判断视图是否由集合中的数据创建
//        @Override
//        public boolean isViewFromObject(View view, Object object) {
//            return view == object;
//        }
//
//        //返回一个具体的item对应的视图对象
//        @Override
//        public Object instantiateItem(ViewGroup container, int position) {
//            ImageView imageView = new ImageView(getActivity());
//
//            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
//            //加载具体的图片
//            String imaurl = index.images.get(position).IMAURL;
//            Picasso.with(getActivity()).load(imaurl).into(imageView);
//            //添加到当前的container中
//            container.addView(imageView);
//            return imageView;
//        }
//
//        //销毁指定的视图对象
//        @Override
//        public void destroyItem(ViewGroup container, int position, Object object) {
//            container.removeView((View) object);
//
//        }
//    }
//}
