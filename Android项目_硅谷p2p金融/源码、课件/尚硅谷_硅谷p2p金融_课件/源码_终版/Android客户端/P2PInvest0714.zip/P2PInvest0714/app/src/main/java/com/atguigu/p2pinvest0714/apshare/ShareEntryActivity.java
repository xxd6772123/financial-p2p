package com.atguigu.p2pinvest0714.apshare;

import cn.sharesdk.alipay.utils.AlipayHandlerActivity;

public class ShareEntryActivity extends AlipayHandlerActivity{

}
