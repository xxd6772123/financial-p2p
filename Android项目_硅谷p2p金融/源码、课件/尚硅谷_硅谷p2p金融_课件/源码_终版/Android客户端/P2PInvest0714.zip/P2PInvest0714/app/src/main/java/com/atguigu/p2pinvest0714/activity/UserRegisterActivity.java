package com.atguigu.p2pinvest0714.activity;

import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.atguigu.p2pinvest0714.R;
import com.atguigu.p2pinvest0714.common.AppNetConfig;
import com.atguigu.p2pinvest0714.common.BaseActivity;
import com.atguigu.p2pinvest0714.utils.MD5Utils;
import com.atguigu.p2pinvest0714.utils.UIUtils;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import java.io.UnsupportedEncodingException;

import butterknife.Bind;
import butterknife.OnClick;

public class UserRegisterActivity extends BaseActivity implements View.OnClickListener {


    @Bind(R.id.iv_top_back)
    ImageView ivTopBack;
    @Bind(R.id.tv_top_title)
    TextView tvTopTitle;
    @Bind(R.id.iv_top_setting)
    ImageView ivTopSetting;
    @Bind(R.id.et_register_number)
    EditText etRegisterNumber;
    @Bind(R.id.et_register_name)
    EditText etRegisterName;
    @Bind(R.id.et_register_pwd)
    EditText etRegisterPwd;
    @Bind(R.id.et_register_pwdagain)
    EditText etRegisterPwdagain;
    @Bind(R.id.btn_register)
    Button btnRegister;

    @Override
    protected void initTitle() {
        ivTopBack.setVisibility(View.VISIBLE);
        tvTopTitle.setText("用户注册");
        ivTopSetting.setVisibility(View.INVISIBLE);
    }

    @OnClick(R.id.iv_top_back)
    public void back(View view) {
        removeCurrentActivity();
    }

    @Override
    protected void initData() {
        //给Button设置点击事件
        btnRegister.setOnClickListener(this);
    }


    @Override
    protected int getLayoutId() {
        return R.layout.activity_user_register;
    }

    @Override
    public void onClick(View v) {
        String name = etRegisterName.getText().toString();
        String phone = etRegisterNumber.getText().toString().trim();
        String password = etRegisterPwd.getText().toString().trim();
        String verify = etRegisterPwdagain.getText().toString().trim();
        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(phone) || TextUtils.isEmpty(password) || TextUtils.isEmpty(verify)) {
            Toast.makeText(UserRegisterActivity.this, "输入的信息不能为空", Toast.LENGTH_SHORT).show();

        } else if (!password.equals(verify)) {
            etRegisterPwd.setText("");
            etRegisterPwdagain.setText("");
            Toast.makeText(UserRegisterActivity.this, "两次输入的密码不一致", Toast.LENGTH_SHORT).show();
        } else {
            //联网发送用户信息给服务器
            String register = AppNetConfig.REGISTER;
            RequestParams params = new RequestParams();
            try {
                //为了避免出现乱码
                name = new String(name.getBytes(), "UTF-8");
                params.put("name", name);
                params.put("phone", phone);
                password = MD5Utils.MD5(password);
                params.put("password", password);
                client.post(register, params, new AsyncHttpResponseHandler() {
                    @Override
                    public void onSuccess(String content) {
                        //如果注册的电话号码的用户已经存在，提示：用户已注册
                        JSONObject jsonObject = JSON.parseObject(content);
                        boolean isExist = jsonObject.getBoolean("isExist");
                        if (isExist) {
                            Toast.makeText(UserRegisterActivity.this, "用户已注册", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        //如果之前用户没有注册过，则注册成功
                        Toast.makeText(UserRegisterActivity.this, "注册成功", Toast.LENGTH_SHORT).show();
                        etRegisterName.setText("");
                        etRegisterNumber.setText("");
                        etRegisterPwd.setText("");
                        etRegisterPwdagain.setText("");

                        UIUtils.getHandler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                removeCurrentActivity();
                            }
                        }, 2000);
                    }

                    @Override
                    public void onFailure(Throwable error, String content) {
                        Toast.makeText(UserRegisterActivity.this, "网络异常，注册失败", Toast.LENGTH_SHORT).show();

                    }
                });
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
    }
}
