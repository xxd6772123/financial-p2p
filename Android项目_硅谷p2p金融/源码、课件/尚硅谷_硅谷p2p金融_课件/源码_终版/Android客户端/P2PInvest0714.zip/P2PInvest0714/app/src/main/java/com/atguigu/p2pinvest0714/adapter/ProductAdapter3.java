package com.atguigu.p2pinvest0714.adapter;

import com.atguigu.p2pinvest0714.bean.Product;

import java.util.List;

/**
 * Created by shkstart on 2016/11/15 0015.
 */
public class ProductAdapter3 extends MyBaseAdapter3<Product> {
    public ProductAdapter3(List<Product> list) {
        super(list);
    }

    @Override
    protected BaseHolder getHolder() {

        return new MyHolder();
    }
}
