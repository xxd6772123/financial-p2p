package com.atguigu.p2pinvest0714.bean;

/**
 * Created by shkstart on 2016/11/12 0012.
 */
public class Image {
    public String ID;
    public String IMAPAURL;
    public String IMAURL;

}
