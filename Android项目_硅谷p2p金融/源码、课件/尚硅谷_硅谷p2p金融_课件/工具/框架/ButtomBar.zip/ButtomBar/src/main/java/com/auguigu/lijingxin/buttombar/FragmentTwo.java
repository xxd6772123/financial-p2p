package com.auguigu.lijingxin.buttombar;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * 作者：李婧馨 on 2016/9/19 20:52
 * 电话: 15180176050
 * QQ号：1109711383
 * 作用：xxxx
 */
public class FragmentTwo extends Fragment {

    View v;
    Context context;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_two, container,false);
        context = getActivity();
        return v;
    }
}
