package com.atguigu.p2pinvest0828.bean;

/**
 * Created by shkstart on 2016/12/2 0002.
 */
public class Image {
    public String ID;
    public String IMAPAURL;
    public String IMAURL;

}
