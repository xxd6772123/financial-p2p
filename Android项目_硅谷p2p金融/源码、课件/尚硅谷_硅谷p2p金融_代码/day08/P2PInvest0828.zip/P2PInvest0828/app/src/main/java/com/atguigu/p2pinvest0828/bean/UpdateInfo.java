package com.atguigu.p2pinvest0828.bean;

/**
 * Created by shkstart on 2016/12/10 0010.
 */
public class UpdateInfo {
    public String version;//服务器的最新版本值
    public String apkUrl;//最新版本的路径
    public String desc;//版本更新细节
}
