package com.atguigu.p2pinvest0828.fragment;

import com.atguigu.p2pinvest0828.R;
import com.atguigu.p2pinvest0828.common.BaseFragment;
import com.loopj.android.http.RequestParams;

/**
 * Created by shkstart on 2016/12/5 0005.
 */
public class ProductRecommondFragment extends BaseFragment {
    @Override
    protected RequestParams getParams() {
        return null;
    }

    @Override
    protected String getUrl() {
        return null;
    }

    @Override
    protected void initData(String content) {

    }

    @Override
    protected void initTitle() {

    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_productrecommond;
    }
}
