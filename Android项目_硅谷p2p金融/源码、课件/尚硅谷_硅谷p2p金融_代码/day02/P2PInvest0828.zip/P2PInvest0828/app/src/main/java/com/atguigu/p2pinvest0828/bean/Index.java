package com.atguigu.p2pinvest0828.bean;

import java.util.List;

/**
 * Created by shkstart on 2016/12/2 0002.
 */
public class Index {
    public Product product;
    public List<Image> images;
}
