package com.atguigu.p2pinvest0828.apshare;

import cn.sharesdk.alipay.utils.AlipayHandlerActivity;

public class ShareEntryActivity extends AlipayHandlerActivity{

}
